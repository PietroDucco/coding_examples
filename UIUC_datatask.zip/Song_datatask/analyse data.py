import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

#load  baseline
df_baseline=pd.read_csv('baseline_survey.csv').drop(['Unnamed: 0'],axis=1)
#load_treatment
df_treatment=pd.read_csv('treatment_assignment.csv').drop(['Unnamed: 0'],axis=1)
#load endline_csv
df_endline=pd.read_csv('endline_survey.csv').drop(['Unnamed: 0'],axis=1)
#final dataset is available
df=pd.concat([df_baseline.set_index('unique_id'),df_treatment.set_index('unique_id'),df_endline.set_index('unique_id')],axis=1)


#############################
### MISSING VALUES
########################


#given the assumptions we can drop the NA (they are not correlated with the treatment status)

#after a quick check there are no other NAs besides those belongin to vax_intention_endline.

#build a correlation matrix of the df variable. Instead of the vax_intention_endline I used its presence, so the correlation will be between one variable and the presence of vax_intention_endline
corr=pd.concat([df.vax_intention_endline.notna().map({True:1,False:0}),(pd.get_dummies(df.drop('vax_intention_endline',axis=1)))],axis=1).corr()
#The correlation matrix displays very low values for the vax_intention_endline variable presence
max_corr=corr.abs().vax_intention_endline.iloc[1:].max()

#I will analyze with a logistic regression if any variable affects the presence of the variable 'vax_intention_endline'

df_reg=pd.get_dummies(df.drop(['vax_intention_endline'],axis=1),drop_first=True).astype(int)

# Specify the target variable
target_variable = 'vax_intention_endline'

# Specify the predictor variables (exclude the target variable)
predictor_variables = [col for col in df_reg.columns if col != target_variable]

# Add a constant term to the predictors for the intercept
X = sm.add_constant(df_reg[predictor_variables])

# Specify the target variable
y = df[target_variable].isna().astype(int)

# Fit logistic regression model
logit_model = sm.Logit(y, X)
result = logit_model.fit()

# Display the summary table of results
print(result.summary().as_latex())

#generate probabilities
df['probs']=result.predict(X)

#generate prob bins
df['probs_bins']=pd.cut(df['probs'],[0,0.05,0.1,0.15,0.20,0.25,0.3,0.35,1])
#look if the observations with a smaller difference (before and after treatment) are more likely to miss or not.

#build table about probs_bins and employment_status
#generate counts
counts_prob_emp=df.dropna().groupby(['employment_status','probs_bins'])['vax_intention'].count().rename('count')
#generate values for intention in baseline and endline survey
values_prob_emp = df.dropna().groupby(['employment_status','probs_bins'])[['vax_intention','vax_intention_endline']].mean()
#generate difference between the two columns of the above dataset
diff_prob_emp =df.dropna().groupby(['employment_status','probs_bins'])[['vax_intention','vax_intention_endline']].mean().diff(axis=1).iloc[:,1].rename('diff')
#concatenate columns on the same index
df_prob_emp=pd.concat([values_prob_emp,diff_prob_emp,counts_prob_emp],axis=1)
#to latex
print(df_prob_emp[df_prob_emp['count']>0].to_latex(float_format='%.2f'))




###############
# ANALYSIS
#####################


df=df.dropna()



########intention to vaccinate, description of the dependent variable for different groups
#treatment was randomly assigned
#correlation between baseline and endline vaccination intention
df.loc[:,['vax_intention','vax_intention_endline']].corr()

#creation of descriptive statistics by groups

#creation of age bins
df['age_bin']=pd.cut(df['age'],[18,30,40,50,60,70,100])
#divide family income in 4 quantiles
df['fam_inc_quant']=pd.qcut(df['family_income'],4,duplicates='drop')

category=['race','sex','marital_status','employment_status','area','metropolitan','age_bin','fam_inc_quant']

#create tables with vax intention average by category
table_categories=pd.DataFrame()
for i in category:
    view=df.groupby(i)[['vax_intention','vax_intention_endline']].mean()
    diff=view.diff(axis=1).iloc[:,1].rename('diff')
    count=df.groupby(i)['vax_intention'].count().rename('n obs')
    tab=pd.concat([view,diff,count],axis=1)
    table_categories=pd.concat([table_categories,tab],axis=0)
    
table_categories.columns=['vax int','vax int endline','diff','n obs']

print(table_categories.to_latex(float_format='%.2f'))


df['treatment']=df['treatment'].map({'reason':'reason','emotion':'emotion','no_treatment':'no treatment'})
#check for NAs 
df.groupby(['treatment'])[['vax_intention','vax_intention_endline']].mean()

#create dummies in terms of categorical variables to compute correlation etc.

#for each categorical variable create dummies and join them.
df_an=df.loc[:,['vax_intention','vax_intention_endline','treatment']].copy() #for analysis
categorical_vars=['sex','metropolitan','education','marital_status','family_income','race','employment_status']
for i in categorical_vars:
    dumm=pd.get_dummies(df[f'{i}'],drop_first=True).astype(float) #(-1,1] has been dropped
    df_an=pd.concat([df_an,dumm],axis=1)

df_an['reason']=df_an['treatment']=='reason'
df_an['emotion']=df_an['treatment']=='emotion'
df_an=df_an.drop(['treatment'],axis=1)



#compare outcome in terms of treatment
treatment_val=df.groupby(['treatment'])[['vax_intention','vax_intention_endline']].mean()
treatment_diff=df.groupby(['treatment'])[['vax_intention','vax_intention_endline']].mean().diff(axis=1).iloc[:,1].rename('diff')
treatment_count=df.groupby(['treatment'])['vax_intention'].count()

treatment_val.index = pd.MultiIndex.from_product([['TOTAL'], treatment_val.index], names=['General', 'treatment'])
treatment_diff.index = pd.MultiIndex.from_product([['TOTAL'], treatment_diff.index], names=['General', 'treatment'])
treatment_count.index=pd.MultiIndex.from_product([['TOTAL'], treatment_count.index], names=['General', 'treatment'])


#Look if treatment is more effective on some groups than others. For example, it is more effective on rural people etc.
metropolitan_val=df.groupby(['metropolitan','treatment'])[['vax_intention','vax_intention_endline']].mean()
metropolitan_diff=df.groupby(['metropolitan','treatment'])[['vax_intention','vax_intention_endline']].mean().diff(axis=1).iloc[:,1].rename('diff')
metropolitan_count=df.groupby(['metropolitan','treatment'])['vax_intention'].count()

#education
ed_val=df.groupby(['education','treatment'])[['vax_intention','vax_intention_endline']].mean()
ed_diff=df.groupby(['education','treatment'])[['vax_intention','vax_intention_endline']].mean().diff(axis=1).iloc[:,1].rename('diff')
ed_count=df.groupby(['education','treatment'])['vax_intention'].count()

#merge and create tables
val_table=pd.concat([treatment_val,metropolitan_val,ed_val],axis=0)
diff_table=pd.concat([treatment_diff,metropolitan_diff,ed_diff],axis=0)
count_table=pd.concat([treatment_count,metropolitan_count,ed_count],axis=0)

table_categories_treatment=pd.concat([val_table,diff_table,count_table],axis=1)

print(table_categories_treatment.to_latex(float_format='%.2f'))


#intention to vaccinate (before and after treatment) by income and treatment 
inc_treat=df.groupby(['family_income','treatment'])[['vax_intention','vax_intention_endline']].mean()
#plot
#mean intertemporal (before and after treatment) vaccination difference
inc_treat.diff(axis=1).unstack('treatment').iloc[:,3:].plot()
plt.title('difference in intention to vaccinate by income and treatment')
plt.legend(['emotion','no_treatment','reason'])
plt.xlabel('income in dollars')
plt.ylabel('mean difference in vax intention')
plt.savefig('inc_treat.png')
plt.close()

#vaccination intention (before and after treatment) by marital status and treatment
mar_treat=df.groupby(['marital_status','treatment'])[['vax_intention','vax_intention_endline']].mean()
#mean intertemporal (before and after treatment) vaccination difference

mar_treat.diff(axis=1).unstack().iloc[:,3:].plot(kind='bar')
plt.title('difference in intention to vaccinate by marital status and treatment')
plt.legend(['emotion','no_treatment','reason'])

#add xticks
plt.xticks(rotation=40,size=6)
plt.subplots_adjust(bottom=0.28)
plt.ylabel('mean difference in vax intention')
plt.savefig('mar_treat.png')
plt.close()




#############
#Regression analysis
#################



df['endline']=1

df['emotion']=df['treatment']=='emotion'
df['reason']=df['treatment']=='reason'
#variable that will make interaction terms with 
df_reg_2=pd.get_dummies(df.drop(['area','vax_intention_endline','vax_intention','fam_inc_quant','y','age_bin','probs_bins','treatment','probs','emotion','reason','race','sex','age','endline'],axis=1),drop_first=True).astype(int)

#create interaction variables for emotion treatment
df_reg_2_emotion=(df['emotion']*df_reg_2.T).T
df_reg_2_emotion.columns = ['emotion_' + item for item in df_reg_2_emotion.columns]

#creates interaction variables for reason treatment
df_reg_2_reason=(df['reason']*df_reg_2.T).T
df_reg_2_reason.columns= ['reason_' + item for item in df_reg_2_reason.columns]

#concatenate treatment effects and interaction terms
df_reg_2_final=pd.concat([df['emotion'].astype(int),df['reason'].astype(int),df_reg_2_emotion,df_reg_2_reason],axis=1)

#prepare data for the regression
#use the dataset from before
df_reg_baseline= df_reg.drop(['vax_intention','treatment_no_treatment','treatment_reason'],axis=1).loc[df.index]
y_baseline=df['vax_intention'].rename('y')
#same as before but has a dummy for endline, treatment dummies and treatment interaction variables

#create variables
df_reg_endline=pd.concat([df['endline'],df_reg_baseline,df['emotion'].astype(int),df['reason'].astype(int),df_reg_2_emotion,df_reg_2_reason],axis=1).loc[df.index]
y_endline=df['vax_intention_endline'].rename('y')
#create X,y
X_final=sm.add_constant(pd.concat([df_reg_baseline,df_reg_endline],axis=0).fillna(0).reset_index(drop=True))
y_final=pd.concat([y_baseline,y_endline],axis=0).reset_index(drop=True)

#model
logit_model_2=sm.Logit(y_final,X_final)
result=logit_model_2.fit()

#print regression summary
print(result.summary().as_latex())

coeff=result.params
impact_odd=np.exp(coeff)-1
