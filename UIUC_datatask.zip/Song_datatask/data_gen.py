#Imagine the team is conducting a field experiment to assess the effectiveness of different Facebook ad campaigns in increasing COVID-19 vaccine uptake. The experiment involves two distinct ad strategies appealing to reason and emotions, respectively.
import pandas as pd
import numpy as np


#create baseline survey


# Set a random seed for reproducibility
np.random.seed(42)

# Number of rows in the dataset
num_rows = 5000

# Generate Unique IDs
unique_ids = range(1, num_rows + 1)



#initial data
data_in=pd.read_csv('oct23pub.csv')
#PWSSWGT person weight
#PEEDUCA education level
#PEMARITL marital status
#GESTFIPS state fips
#GTMETSTA metropolitan status
#PRTAGE age
#PEMLR employment status
#HEFAMINC family income
#PESEX sex
#PTDTRACE race

#move columns to UPPERCASE
data_in.columns=data_in.columns.str.upper()
#only keep variables of interest
data_in=data_in.loc[:,['PWSSWGT','PESEX','PEEDUCA','PEMARITL','HEFAMINC','PEMLR','GEDIV','GTMETSTA','PRTAGE','PTDTRACE']].copy()
#only keep people above 18, I decided so because vaccination is an individual decision and when underage you have to obey your family will
#Yes in the CPS family can be built and so to 
data_in=data_in[data_in.PRTAGE>=18]
data=data_in.sample(5000, weights=data_in.PWSSWGT,replace=True)
data=data.reset_index(drop=True) #the index supply a unique identifier
data['unique_id']=data.index
maps={}
maps['GEDIV'] = {
    1: 'NEW ENGLAND',
    2: 'MIDDLE ATLANTIC',
    3: 'EAST NORTH CENTRAL',
    4: 'WEST NORTH CENTRAL',
    5: 'SOUTH ATLANTIC',
    6: 'EAST SOUTH CENTRAL',
    7: 'WEST SOUTH CENTRAL',
    8: 'MOUNTAIN',
    9: 'PACIFIC'
}



maps['PEEDUCA'] = {
    31: '4TH GRADE OR LESS',#LESS THAN 1ST GRADE',
    32: '4TH GRADE OR LESS',#'1ST, 2ND, 3RD OR 4TH GRADE',
    33: '8TH-4TH GRADE',#'5TH OR 6TH GRADE',
    34: '8TH-4TH GRADE',#'7TH OR 8TH GRADE',
    35: '12TH-8TH GRADE',#'9TH GRADE',
    36: '12TH-8TH GRADE',#'10TH GRADE',
    37: '12TH-8TH GRADE',#'11TH GRADE',
    38: '12TH-8TH GRADE',#'12TH GRADE NO DIPLOMA',
    39: 'HIGH SCHOOL GRAD-DIPLOMA OR EQUIV (GED)',
    40: 'SOME COLLEGE BUT NO DEGREE',
    41: 'ASSOCIATE DEGREE',#'ASSOCIATE DEGREE-OCCUPATIONAL/VOCATIONAL',
    42: 'ASSOCIATE DEGREE',#'ASSOCIATE DEGREE-ACADEMIC PROGRAM',
    43: "BACHELOR'S DEGREE (EX: BA, AB, BS)",
    44: "MASTER'S DEGREE (EX: MA, MS, MEng, MEd, MSW)",
    45: 'PROFESSIONAL SCHOOL DEG (EX: MD, DDS, DVM)',
    46: 'DOCTORATE DEGREE (EX: PhD, EdD)'
}

maps['PTDTRACE'] = {
    1: 'White', # Only
    2: 'Black', #Only
    3: 'American Indian, Alaskan Native', # Only
    4: 'Asian', #Only
    5: 'Hawaiian/Pacific Islander', # Only
    6: 'two-or-more-races',#'White-Black',
    7: 'two-or-more-races',#'White-AI',
    8: 'two-or-more-races',#'White-Asian',
    9: 'two-or-more-races',#'White-HP',
    10: 'two-or-more-races',#'Black-AI',
    11: 'two-or-more-races',#'Black-Asian',
    12: 'two-or-more-races',#'Black-HP',
    13: 'two-or-more-races',#'AI-Asian',
    14: 'two-or-more-races',#'AI-HP',
    15: 'two-or-more-races',#'Asian-HP',
    16: 'two-or-more-races',#'W-B-AI',
    17: 'two-or-more-races',#'W-B-A',
    18: 'two-or-more-races',#'W-B-HP',
    19: 'two-or-more-races',#'W-AI-A',
    20: 'two-or-more-races',#'W-AI-HP',
    21: 'two-or-more-races',#'W-A-HP',
    22: 'two-or-more-races',#'B-AI-A',
    23: 'two-or-more-races',#'W-B-AI-A',
    24: 'two-or-more-races',#'W-AI-A-HP',
    25: 'two-or-more-races',#'Other 3 Race Combinations',
    26: 'two-or-more-races',#'Other 4 and 5 Race Combinations'
}


maps['PEMARITL'] = {
    1: 'MARRIED - SPOUSE PRESENT',
    2: 'MARRIED - SPOUSE ABSENT',
    3: 'WIDOWED',
    4: 'DIVORCED',
    5: 'SEPARATED',
    6: 'NEVER MARRIED'
}

maps['GTMETSTA'] = {
    1: 'METROPOLITAN',
    2: 'NONMETROPOLITAN',
    3: 'NOT IDENTIFIED'
}

maps['HEFAMINC'] = {
    1: 2500,
    2: 5000,
    3: 7500,
    4: 10000,
    5: 12500,
    6: 15000,
    7: 20000,
    8: 25000,
    9: 30000,
    10: 35000,
    11: 40000,
    12: 50000,
    13: 60000,
    14: 75000,
    15: 100000,
    16: 150000
}


maps['PEMLR'] = {
    1: 'EMPLOYED',#'-AT WORK',
    2: 'EMPLOYED', #-ABSENT',
    3: 'UNEMPLOYED', #-ON LAYOFF
    4: 'UNEMPLOYED',#-LOOKING
    5: 'NOT IN LABOR FORCE', # --RETIRED
    6: 'NOT IN LABOR FORCE', # -DISABLED
    7: 'NOT IN LABOR FORCE' #-OTHER
     
}

maps['PESEX'] = {
    1: 'MALE',
    2: 'FEMALE'
}



for i in data.columns:
    if i in maps.keys():
        data[f'{i}']=data[f'{i}'].map(maps[f'{i}'])

#change columns name
data.columns=['weight','sex','education','marital_status','family_income','employment_status','area','metropolitan','age','race','unique_id']



#creation of the dependent variable (vaccination intention)
#The model behind the dependent variable is simple.
#First I compute the probability of vaccination based on characteristics and random terms, then according to this probability the respondents pick a vaccination intention.
#For example if the probability of vaccination is 70% the vaccinationation intention will drawn YES with a 70% chance.
#The model behind probability of vaccination is a linear model where each characteristics is randomly assigned a value, picked from a uniform between -0.1 and 0.1
#I refrained from picking myself the values since they will require some assumptions that may be more or less credible.
#For example we can expect education to have a positive impact on vaccination, what can we say about marital status? Maybe some of the married couples are religious and skeptical of new drugs.
#However marriage may also be an indicator of risk aversion and this could change the previous hypothesis.


#impact values (or coefficients) are generated
education_impact = {category: np.random.uniform(-0.1, 0.1) for category in data.education.unique()}
sex_impact = {category: np.random.uniform(-0.1, 0.1) for category in data.sex.unique()}
metropolitan_impact = {category: np.random.uniform(-0.1, 0.1) for category in data.metropolitan.unique()}
marital_status_impact = {category: np.random.uniform(-0.1, 0.1) for category in data.marital_status.unique()}
employment_status_impact = {category: np.random.uniform(-0.1, 0.1) for category in data.employment_status.unique()}
race_impact= {category: np.random.uniform(-0.1,0.1) for category in data.race.unique()}


#create impact variables
data['education_impact']=data['education'].map(education_impact)
data['age_impact']=data['age']*-0.001 +0.048 #0.048 is used to account for the mean effect
data['sex_impact']=data['sex'].map(sex_impact)
data['metropolitan_impact']=data['metropolitan'].map(metropolitan_impact)
data['marital_status_impact']=data['marital_status'].map(marital_status_impact)
data['employment_status_impact']=data['employment_status'].map(employment_status_impact)
data['race_impact']=data['race'].map(race_impact)
data['family_income_impact']=data['family_income']*0.000001 #- 0.07 # 100k have an impact of 0.1, 0.07 is used to account for the mean effect



# Create a new variable as the sum of impact values and a normally distributed random term
impact_sum = data[['education_impact', 'age_impact', 'sex_impact', 'metropolitan_impact',
                  'marital_status_impact', 'family_income_impact', 'employment_status_impact','race_impact','sex_impact']].sum(axis=1)

random_term = np.random.normal(loc=0, scale=0.3, size=num_rows)

#give a degree of randomness to the sum. This includes the impact of all the characteristics of an individual that are not object of analysis
data['impact_sum'] = impact_sum + random_term

#generate probability of vaccination.
#I took as basis 0.5 as the intercept of our model, this may be unrealistic. 
data['prob_vax']=data['impact_sum'] + 0.5

#np.random.rand is a uniform distribution, between 0 and 1. Drawing vaxxination intention.
data['vax_intention']=np.where(data['prob_vax'] >= np.random.rand(num_rows), 1, 0)

#columns that do not appear in the survey data
cols_to_drop=['weight','prob_vax','impact_sum','education_impact', 'race_impact','age_impact', 'sex_impact', 'metropolitan_impact', 'marital_status_impact', 'family_income_impact', 'employment_status_impact']


#save the baseline dataset
data.drop(cols_to_drop,axis=1).to_csv('baseline_survey.csv')

#treatment
treatment_options = ['reason', 'emotion', 'no_treatment']
data['treatment'] = np.random.choice(treatment_options, size=num_rows, p=[1/3, 1/3, 1/3])
#treatment impact
treatment_impact_values = {'reason': 0.2, 'emotion': 0.1, 'no_treatment': 0}
data['treatment_impact'] = data['treatment'].map(treatment_impact_values) + (data['treatment']=='emotion')*(data['family_income']<=50000)*0.1 + (data['treatment']=='reason')*(data['metropolitan']=='METROPOLITAN')*0.1

#save treatment assignment
data.loc[:,['unique_id','treatment']].to_csv('treatment_assignment.csv')

#change in vaxxination uptake in the general population
vax_trend=0.1

#update prob_vax after treatment
data['prob_vax_endline'] = data['prob_vax'] + data['treatment_impact'] + vax_trend

#generate vaccination variable after treatment. #Could think of it as "if vaccine was available today, would you take it?"
data['vax_intention_endline'] = np.where(data['prob_vax_endline']  >= np.random.rand(num_rows), 1, 0)


#drop 500 rows and more likely to be dropped if you are employed
weights = np.where(data['employment_status'] == 'EMPLOYED', 0.9, 0.1)

# Sample 500 rows with specified weights
sampled_df = data.sample(n=500, weights=weights, random_state=42)
data_dropped=data.drop(sampled_df.index)

#save endline survey
data_dropped.loc[:,['unique_id','vax_intention_endline']].to_csv('endline_survey.csv')


